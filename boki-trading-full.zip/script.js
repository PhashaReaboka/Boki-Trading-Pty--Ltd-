// Auto update footer year
document.getElementById('year').textContent = new Date().getFullYear();